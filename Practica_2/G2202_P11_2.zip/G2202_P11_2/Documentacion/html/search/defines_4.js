var searchData=
[
  ['segundos',['SEGUNDOS',['../ejercicio2_8c.html#aab4b06439c9f4eb24f6d31202e3cdb7c',1,'SEGUNDOS():&#160;ejercicio2.c'],['../ejercicio4_8c.html#aab4b06439c9f4eb24f6d31202e3cdb7c',1,'SEGUNDOS():&#160;ejercicio4.c'],['../ejercicio6a_8c.html#a53600094c12347b4b9cae071db04251a',1,'SEGUNDOS():&#160;ejercicio6a.c'],['../ejercicio6b_8c.html#a53600094c12347b4b9cae071db04251a',1,'SEGUNDOS():&#160;ejercicio6b.c'],['../ejercicio9hijos_8c.html#aab4b06439c9f4eb24f6d31202e3cdb7c',1,'SEGUNDOS():&#160;ejercicio9hijos.c']]]
];
