var searchData=
[
  ['n_5fcajas',['N_CAJAS',['../ejercicio9_8c.html#a699eef0f4b1a5b984fd6535f6e477ca0',1,'N_CAJAS():&#160;ejercicio9.c'],['../ejercicio9hijos_8c.html#a699eef0f4b1a5b984fd6535f6e477ca0',1,'N_CAJAS():&#160;ejercicio9hijos.c']]],
  ['n_5foperaciones',['N_OPERACIONES',['../ejercicio9_8c.html#aa1375ad0a0b107258144b696e83178b8',1,'ejercicio9.c']]],
  ['num_5fhijos',['NUM_HIJOS',['../ejercicio2_8c.html#a9dd395f2e0046c1513c84dfcfb9e54da',1,'ejercicio2.c']]],
  ['num_5fproc',['NUM_PROC',['../ejercicio6a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio6a.c'],['../ejercicio6b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio6b.c']]],
  ['num_5fprocesos_5fterminados',['num_procesos_terminados',['../ejercicio9_8c.html#a75f0f696d5c258ee4dad0856ed01005b',1,'ejercicio9.c']]]
];
