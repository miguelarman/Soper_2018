var searchData=
[
  ['tam_5fpath',['TAM_PATH',['../ejercicio9_8c.html#ae3dd95f54e7825e43b5b544aa1130274',1,'ejercicio9.c']]],
  ['tamanio_5fargv_5fhijos',['TAMANIO_ARGV_HIJOS',['../ejercicio9_8c.html#ae299a394c67af9a1d4dd998ceb7bc8fd',1,'ejercicio9.c']]]
];
