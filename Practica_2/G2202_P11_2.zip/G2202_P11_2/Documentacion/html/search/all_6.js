var searchData=
[
  ['oset',['oset',['../ejercicio9_8c.html#afbc2cbe34b6c6136e7a933faec748f78',1,'ejercicio9.c']]]
];
