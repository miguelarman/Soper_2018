var searchData=
[
  ['param',['param',['../structparam.html',1,'param'],['../ejercicio13_8c.html#accbaceac5fd1c647a17f4024f3bef2a8',1,'Param():&#160;ejercicio13.c']]]
];
