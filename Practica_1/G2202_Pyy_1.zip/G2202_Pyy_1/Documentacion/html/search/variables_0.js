var searchData=
[
  ['cadena',['cadena',['../struct__estructura.html#a29bf54eee61a6cc3369758a5ee0cd1fa',1,'_estructura']]]
];
