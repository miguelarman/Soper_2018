var searchData=
[
  ['buffer_5fsize',['BUFFER_SIZE',['../ejercicio13_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;ejercicio13.c'],['../ejercicio9_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;ejercicio9.c']]]
];
