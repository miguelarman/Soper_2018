var searchData=
[
  ['entero',['entero',['../struct__estructura.html#a7fefe0e76b29d4f973ce0a45c7fed838',1,'_estructura']]]
];
