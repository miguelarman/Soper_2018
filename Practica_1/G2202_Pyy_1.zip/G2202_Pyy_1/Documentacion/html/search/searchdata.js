var indexSectionsWithContent =
{
  0: "_abcdefilmnp",
  1: "_p",
  2: "e",
  3: "cfm",
  4: "cdeim",
  5: "ep",
  6: "abelmn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "typedefs",
  6: "defines"
};

