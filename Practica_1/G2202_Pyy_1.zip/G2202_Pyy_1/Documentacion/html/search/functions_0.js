var searchData=
[
  ['calcula_5fmatriz',['calcula_matriz',['../ejercicio13_8c.html#a745c6f5f79dff189528803cff6a720bd',1,'ejercicio13.c']]],
  ['calcula_5fprimos',['calcula_primos',['../ejercicio12a_8c.html#a56aaeeee5215f31221b6ae0d5132fd1d',1,'calcula_primos(int N):&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#aff9e17a51f7b65d5358d84efe5273118',1,'calcula_primos(void *arg):&#160;ejercicio12b.c']]]
];
