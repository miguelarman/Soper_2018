var searchData=
[
  ['main',['main',['../ejercicio12a_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;ejercicio12b.c'],['../ejercicio13_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ejercicio13.c'],['../ejercicio9_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;ejercicio9.c']]]
];
