var searchData=
[
  ['estructura',['estructura',['../ejercicio12a_8c.html#a30f36ffd6c23b2391c7ff0e05080905b',1,'estructura():&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#a30f36ffd6c23b2391c7ff0e05080905b',1,'estructura():&#160;ejercicio12b.c']]]
];
