var searchData=
[
  ['lectura',['LECTURA',['../ejercicio9_8c.html#a0f47050799b9308fe388baf6478e6fc9',1,'ejercicio9.c']]]
];
