var searchData=
[
  ['max_5fcad',['MAX_CAD',['../ejercicio6_8c.html#a470986be94bc6e787048bf6263e44b6f',1,'ejercicio6.c']]],
  ['max_5fpath',['MAX_PATH',['../ejercicio8_8c.html#ab99ded389af74001a6298fc9e44e74e5',1,'ejercicio8.c']]],
  ['mensaje_5fsize',['MENSAJE_SIZE',['../ejercicio9_8c.html#a81554af70e8eee1b1495b9330d93dcb4',1,'ejercicio9.c']]]
];
