var searchData=
[
  ['num_5fproc',['NUM_PROC',['../ejercicio4a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio4a.c'],['../ejercicio4b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio4b.c'],['../ejercicio5a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio5a.c'],['../ejercicio5b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio5b.c']]],
  ['numero_5fhilos',['NUMERO_HILOS',['../ejercicio12b_8c.html#a0d6c0643ebe1a8702d8c82dfaf5314d2',1,'ejercicio12b.c']]],
  ['numero_5fprocesos',['NUMERO_PROCESOS',['../ejercicio12a_8c.html#a3bbd3605965729bd6678d8b5936934b1',1,'ejercicio12a.c']]]
];
