var searchData=
[
  ['inicializa_5ffichero_5fentrada',['inicializa_fichero_entrada',['../cadena__montaje_8c.html#ad8de574186cfad91faa91da1cc5676ed',1,'cadena_montaje.c']]]
];
