var searchData=
[
  ['numero_5fmensajes_5fpendientes',['numero_mensajes_pendientes',['../cadena__montaje_8c.html#aad82e5401fadde42522ed35be4cd3d8d',1,'cadena_montaje.c']]]
];
