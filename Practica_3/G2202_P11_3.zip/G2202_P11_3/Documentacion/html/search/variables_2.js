var searchData=
[
  ['nombre',['nombre',['../structinfo.html#a3fabfdb9002c8d356ddaa529a4bc473f',1,'info']]]
];
