var searchData=
[
  ['id',['id',['../structinfo.html#afe86f23d8bd5fd8d139e39a5b1a01171',1,'info']]],
  ['info',['info',['../structinfo.html',1,'']]],
  ['informacion',['Informacion',['../ejercicio2_8c.html#a956fb41d1afdcb20ab642b7e379faaef',1,'Informacion():&#160;ejercicio2.c'],['../ejercicio2__solved_8c.html#a956fb41d1afdcb20ab642b7e379faaef',1,'Informacion():&#160;ejercicio2_solved.c']]],
  ['inicializa_5ffichero_5fentrada',['inicializa_fichero_entrada',['../cadena__montaje_8c.html#ad8de574186cfad91faa91da1cc5676ed',1,'cadena_montaje.c']]]
];
