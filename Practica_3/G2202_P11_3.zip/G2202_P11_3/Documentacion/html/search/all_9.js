var searchData=
[
  ['ok',['OK',['../cadena__montaje_8c.html#aba51915c87d64af47fb1cc59348961c9',1,'cadena_montaje.c']]]
];
