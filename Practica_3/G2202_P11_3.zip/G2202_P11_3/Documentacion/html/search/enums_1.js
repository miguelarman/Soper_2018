var searchData=
[
  ['tipo_5fmensaje',['Tipo_Mensaje',['../cadena__montaje_8c.html#a0e486f8855adca8df35ba293f5272165',1,'cadena_montaje.c']]]
];
