var searchData=
[
  ['max_5fsleep_5fconsumidor',['MAX_SLEEP_CONSUMIDOR',['../ejercicio3_8c.html#ab94525ce2092a129a40a9d69631e2b70',1,'ejercicio3.c']]],
  ['max_5fsleep_5fproductor',['MAX_SLEEP_PRODUCTOR',['../ejercicio3_8c.html#ac256970a7e11e83f28ed41b6f1d810fe',1,'ejercicio3.c']]],
  ['max_5fwait',['MAX_WAIT',['../ejercicio2_8c.html#a41b0180f12af925ed6e81a3566c0e448',1,'MAX_WAIT():&#160;ejercicio2.c'],['../ejercicio2__solved_8c.html#a41b0180f12af925ed6e81a3566c0e448',1,'MAX_WAIT():&#160;ejercicio2_solved.c']]],
  ['min_5fsleep_5fconsumidor',['MIN_SLEEP_CONSUMIDOR',['../ejercicio3_8c.html#aa328bf304d78d9986f86b81979e994e8',1,'ejercicio3.c']]],
  ['min_5fsleep_5fproductor',['MIN_SLEEP_PRODUCTOR',['../ejercicio3_8c.html#a9a2f1076818c57a2ae3738d7a6d7e0ef',1,'ejercicio3.c']]],
  ['min_5fwait',['MIN_WAIT',['../ejercicio2_8c.html#a216b4d0ad666e28fd731b4c0029d57e9',1,'MIN_WAIT():&#160;ejercicio2.c'],['../ejercicio2__solved_8c.html#a216b4d0ad666e28fd731b4c0029d57e9',1,'MIN_WAIT():&#160;ejercicio2_solved.c']]]
];
