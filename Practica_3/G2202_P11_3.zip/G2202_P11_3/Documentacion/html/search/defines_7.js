var searchData=
[
  ['tamanio_5fnombre',['TAMANIO_NOMBRE',['../ejercicio2_8c.html#adc9a965ddfa49420375f71c462043e5a',1,'TAMANIO_NOMBRE():&#160;ejercicio2.c'],['../ejercicio2__solved_8c.html#adc9a965ddfa49420375f71c462043e5a',1,'TAMANIO_NOMBRE():&#160;ejercicio2_solved.c']]],
  ['tamano_5fmensaje',['TAMANO_MENSAJE',['../cadena__montaje_8c.html#a4487334865d4091453c8cdb57316f37b',1,'cadena_montaje.c']]]
];
