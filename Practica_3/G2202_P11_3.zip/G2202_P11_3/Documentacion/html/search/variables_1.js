var searchData=
[
  ['mtext',['mtext',['../structmsgbuf.html#acd5852d923f0d7966e23ee7c34ab9564',1,'msgbuf']]],
  ['mtype',['mtype',['../structmsgbuf.html#a12a4780abaa96553f2ebf5fafeb58360',1,'msgbuf']]]
];
