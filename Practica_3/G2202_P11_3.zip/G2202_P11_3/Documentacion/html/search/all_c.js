var searchData=
[
  ['segundo_5fhilo',['segundo_hilo',['../ejercicio4_8c.html#a42f826f05aaa285f380192dba0145058',1,'ejercicio4.c']]],
  ['semaforo_5fentrada',['SEMAFORO_ENTRADA',['../ejercicio2__solved_8c.html#af559fe58dbe5ec25e2fb239dd6552983',1,'ejercicio2_solved.c']]],
  ['semaforo_5fshm',['SEMAFORO_SHM',['../ejercicio2__solved_8c.html#a0fcbfc58c019006326b700c8f4a2eb93',1,'ejercicio2_solved.c']]],
  ['semaforos',['semaforos',['../ejercicio3_8c.html#a4d3eb0a66099756bbd8486888d803bc3',1,'ejercicio3.c']]],
  ['semun',['semun',['../unionsemun.html',1,'']]]
];
