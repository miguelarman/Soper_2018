var searchData=
[
  ['informacion',['Informacion',['../ejercicio2_8c.html#a956fb41d1afdcb20ab642b7e379faaef',1,'Informacion():&#160;ejercicio2.c'],['../ejercicio2__solved_8c.html#a956fb41d1afdcb20ab642b7e379faaef',1,'Informacion():&#160;ejercicio2_solved.c']]]
];
