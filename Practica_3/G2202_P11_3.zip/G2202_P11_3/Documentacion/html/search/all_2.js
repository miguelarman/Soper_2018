var searchData=
[
  ['datos_5fcompartidos',['Datos_Compartidos',['../structDatos__Compartidos.html',1,'']]]
];
