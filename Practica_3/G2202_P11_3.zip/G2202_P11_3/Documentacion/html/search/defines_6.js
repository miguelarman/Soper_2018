var searchData=
[
  ['semaforo_5fentrada',['SEMAFORO_ENTRADA',['../ejercicio2__solved_8c.html#af559fe58dbe5ec25e2fb239dd6552983',1,'ejercicio2_solved.c']]],
  ['semaforo_5fshm',['SEMAFORO_SHM',['../ejercicio2__solved_8c.html#a0fcbfc58c019006326b700c8f4a2eb93',1,'ejercicio2_solved.c']]]
];
