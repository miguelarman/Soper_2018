var searchData=
[
  ['mensaje',['Mensaje',['../cadena__montaje_8c.html#a5fcaf6a8b8da2932626e56d0a73eca51',1,'cadena_montaje.c']]]
];
