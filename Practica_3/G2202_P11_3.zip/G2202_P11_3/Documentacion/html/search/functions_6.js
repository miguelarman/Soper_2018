var searchData=
[
  ['primer_5fhilo',['primer_hilo',['../ejercicio4_8c.html#ac8dc39538fc482d04bf4cc17f5bdbf4d',1,'ejercicio4.c']]],
  ['proceso_5fa',['proceso_A',['../cadena__montaje_8c.html#a85365405c5f9e686cfa05f27ef946069',1,'cadena_montaje.c']]],
  ['proceso_5fb',['proceso_B',['../cadena__montaje_8c.html#a89018cf13e42b790215c6b3214d8b765',1,'cadena_montaje.c']]],
  ['proceso_5fc',['proceso_C',['../cadena__montaje_8c.html#a6ee7c8ef3dd28d4a0e71fe19a5ef8fac',1,'cadena_montaje.c']]],
  ['productor',['productor',['../ejercicio3_8c.html#a5dde5b29615225bf33cdcc98322940aa',1,'ejercicio3.c']]]
];
