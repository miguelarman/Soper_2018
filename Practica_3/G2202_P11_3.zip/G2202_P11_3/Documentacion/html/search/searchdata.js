var indexSectionsWithContent =
{
  0: "acdefikmnoprst",
  1: "dims",
  2: "ace",
  3: "aceimnprs",
  4: "imnp",
  5: "im",
  6: "st",
  7: "p",
  8: "efkmnost"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

