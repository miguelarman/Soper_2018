var searchData=
[
  ['n',['N',['../ejercicio3_8c.html#a0240ac851181b84ac374872dc5434ee4',1,'ejercicio3.c']]],
  ['nombre',['nombre',['../structinfo.html#a3fabfdb9002c8d356ddaa529a4bc473f',1,'info']]],
  ['numero_5fmensajes_5fpendientes',['numero_mensajes_pendientes',['../cadena__montaje_8c.html#aad82e5401fadde42522ed35be4cd3d8d',1,'cadena_montaje.c']]],
  ['numero_5fsemaforos',['NUMERO_SEMAFOROS',['../ejercicio3_8c.html#a6b238cd10197e5a8509e14e3708ad9e5',1,'ejercicio3.c']]]
];
