var searchData=
[
  ['segundo_5fhilo',['segundo_hilo',['../ejercicio4_8c.html#a42f826f05aaa285f380192dba0145058',1,'ejercicio4.c']]]
];
