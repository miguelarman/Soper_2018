var searchData=
[
  ['n',['N',['../ejercicio3_8c.html#a0240ac851181b84ac374872dc5434ee4',1,'ejercicio3.c']]],
  ['numero_5fsemaforos',['NUMERO_SEMAFOROS',['../ejercicio3_8c.html#a6b238cd10197e5a8509e14e3708ad9e5',1,'ejercicio3.c']]]
];
